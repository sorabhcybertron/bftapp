import { ReplaceStringPipe } from './replace-string.pipe';
describe('ReplaceStringPipe', () => {
  it('create an instance', () => {
    const pipe = new ReplaceStringPipe();
    expect(pipe).toBeTruthy();
  });
});
