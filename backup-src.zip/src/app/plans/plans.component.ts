import { Component, OnInit,ViewChild } from '@angular/core';
import { ServerCallsService } from '../server-calls.service'

@Component({
  selector: 'app-plans',
  templateUrl: './plans.component.html',
  styleUrls: ['./plans.component.css']
})
export class PlansComponent implements OnInit {
	background:any;
	subForm : any;
  plans = {
  	"basic":[{"price":0,"dollar":0,"cents":0,"enrollment":0}],
  	"better":[{"price":0,"dollar":0,"cents":0,"enrollment":0}],
  	"best":[{"price":0,"dollar":0,"cents":0,"enrollment":0}],
  };
  planType:string="ach" ;
  constructor(public servercall:ServerCallsService) {
  	this.subForm  = JSON.parse(this.servercall.getLocalStorage("submittedVal"));
    this.background = this.servercall.cleanURL(`url(${this.subForm.background_url})`,'style');;
  }

  ngOnInit() {
	  	this.setPrice();
  }

  setPrice(){
  	if(this.planType == 'ach'){
	  	this.plans.basic[0]["price"] = 19.99;
	  	this.plans.basic[0]["enrollment"] = 149;
	  	this.plans.basic[0]["dollar"] = 19;
	  	this.plans.basic[0]["cents"] = 99;
	  	this.plans.better[0]["price"]= 29.99;
	  	this.plans.better[0]["enrollment"]= 99;
	  	this.plans.better[0]["dollar"] = 29;
	  	this.plans.better[0]["cents"] = 99;
	  	this.plans.best[0]["price"] = 39.99;
	  	this.plans.best[0]["enrollment"] = 49;
	  	this.plans.best[0]["dollar"] = 39;
	  	this.plans.best[0]["cents"] = 99;
	}else{
		this.plans.basic[0]["price"] = 20.99;
	  	this.plans.basic[0]["enrollment"] = 149;
	  	this.plans.basic[0]["dollar"] = 20;
	  	this.plans.basic[0]["cents"] = 99;
	  	this.plans.better[0]["price"] = 30.99;
	  	this.plans.better[0]["enrollment"]= 99;
	  	this.plans.better[0]["dollar"] = 30;
	  	this.plans.better[0]["cents"] = 99;
	  	this.plans.best[0]["price"] = 40.99;
	  	this.plans.best[0]["enrollment"]= 49;
	  	this.plans.best[0]["dollar"] = 40;
	  	this.plans.best[0]["cents"] = 99;
	}
  }
  changePlantype(type){
  	this.planType = type;
  	this.setPrice();
  }
}
