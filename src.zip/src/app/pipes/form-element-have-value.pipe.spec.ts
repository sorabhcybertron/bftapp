import { FormElementHaveValue } from './form-element-have-value.pipe';
describe('FormElementHaveValue', () => {
  it('create an instance', () => {
    const pipe = new FormElementHaveValue();
    expect(pipe).toBeTruthy();
  });
});