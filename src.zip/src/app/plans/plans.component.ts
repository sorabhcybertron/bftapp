import { Component, OnInit,ViewChild } from '@angular/core';
import { ServerCallsService } from '../server-calls.service'

@Component({
  selector: 'app-plans',
  templateUrl: './plans.component.html',
  styleUrls: ['./plans.component.css']
})
export class PlansComponent implements OnInit {
	background:any;
	subForm : any;
	planType:string="ach" ;
	newPlans = {
	  	"basic":{
		  		'ach': {"price":19.99,"dollar":19,"cents":99,"enrollment":149},
		  		'credit': {"price":19.99,"dollar":19,"cents":99,"enrollment":149},
		  		'services': ['Fitness Center Access','Group Excercise Featuring Les Mills'],
		  		'recommended':false
		  	},
	  	"better":{
		  		'ach': {"price":0,"dollar":0,"cents":0,"enrollment":0},
		  		'credit': {"price":0,"dollar":0,"cents":0,"enrollment":0},
		  		'services': [],
		  		'recommended':false
		  	},
	  	"best":{
		  		'ach': {"price":0,"dollar":0,"cents":0,"enrollment":0},
		  		'credit': {"price":0,"dollar":0,"cents":0,"enrollment":0},
		  		'services': [],
		  		'recommended':false
		  	},
	  };

  constructor(public servercall:ServerCallsService) {
  	this.subForm  = JSON.parse(this.servercall.getLocalStorage("submittedVal"));
    this.background = this.servercall.cleanURL(`url(${this.subForm.background_url})`,'style');
  }

  ngOnInit() {
	this.getPlans();
  }

  changePlantype(type){
  	// this.planType = type;
  	// this.getPlans();
  }

  getPlans(){
  	if(this.subForm.inrested_in_plans){
  		if(this.subForm.inrested_in_plans.find(x => { return (x == 'group-training') ? true : false;})){
			//recommend 49.99 			
  			this.newPlans.better.ach.price  = 39.99; 
  			this.newPlans.better.ach.dollar = 39 ;
  			this.newPlans.better.ach.cents = 99 ;
  			this.newPlans.better.ach.enrollment  = 49;
  			this.newPlans.better.services  = ['Fitness Center Access','Group Excercise Featuring Les Mills','SPINLYFE','50% JB Discount','Unlimited Tanning','Child Care','Bf.i.t.t:60 Once Weekly'];

  			this.newPlans.best.ach.price  = 49.99; 
  			this.newPlans.best.ach.dollar = 49 ;
  			this.newPlans.best.ach.cents = 99 ;
  			this.newPlans.best.ach.enrollment  = 49;
  			this.newPlans.best.services  = ['Fitness Center Access','Group Excercise Featuring Les Mills','SPINLYFE','50% JB Discount','Unlimited Tanning','Child Care','Bf.i.t.t:60 Once Weekly','Bf.i.t.t:60 (unlimited)'];

  		//****************************************//
  			this.newPlans.basic.recommended = false;
  			this.newPlans.better.recommended = false;
  			this.newPlans.best.recommended = true;

  		}else if(this.subForm.inrested_in_plans.find(x => { return (x == 'kids-club') ? true : false;})){
  			//recommend 39.99 

  			this.newPlans.better.ach.price  = 39.99; 
  			this.newPlans.better.ach.dollar = 39 ;
  			this.newPlans.better.ach.cents = 99 ;
  			this.newPlans.better.ach.enrollment  = 49;
  			this.newPlans.better.services  = ['Fitness Center Access','Group Excercise Featuring Les Mills','SPINLYFE','50% JB Discount','Unlimited Tanning','Child Care','Bf.i.t.t:60 Once Weekly'];

  			this.newPlans.best.ach.price  = 49.99; 
  			this.newPlans.best.ach.dollar = 49 ;
  			this.newPlans.best.ach.cents = 99 ;
  			this.newPlans.best.ach.enrollment  = 49;
  			this.newPlans.best.services  = ['Fitness Center Access','Group Excercise Featuring Les Mills','SPINLYFE','50% JB Discount','Unlimited Tanning','Child Care','Bf.i.t.t:60 Once Weekly','Bf.i.t.t:60 (unlimited)'];


  			//****************************************//
  			this.newPlans.basic.recommended = false;
  			this.newPlans.better.recommended = true;
  			this.newPlans.best.recommended = false;

  		}else if(this.subForm.inrested_in_plans.find(x => { return (x == 'hr-based-cycling') ? true : false;})
  			|| this.subForm.inrested_in_plans.find(x => { return (x == 'tanning') ? true : false;})
  			){
  			//recommend 29.99 	

  			this.newPlans.better.ach.price  = 29.99; 
  			this.newPlans.better.ach.dollar = 29 ;
  			this.newPlans.better.ach.cents = 99 ;
  			this.newPlans.better.ach.enrollment  = 49;
  			this.newPlans.better.services  = ['Fitness Center Access','Group Excercise Featuring Les Mills','SPINLYFE','50% JB Discount','Unlimited Tanning'];

  			this.newPlans.best.ach.price  = 39.99; 
  			this.newPlans.best.ach.dollar = 39 ;
  			this.newPlans.best.ach.cents = 99 ;
  			this.newPlans.best.ach.enrollment  = 49;
  			this.newPlans.best.services  = ['Fitness Center Access','Group Excercise Featuring Les Mills','SPINLYFE','50% JB Discount','Unlimited Tanning','Child Care','Bf.i.t.t:60 Once Weekly'];
  			
  		//****************************************//
  			this.newPlans.basic.recommended = false;
  			this.newPlans.better.recommended = true;
  			this.newPlans.best.recommended = false;

  		}else{
  			//recommend 19.99 	

  			this.newPlans.better.ach.price  = 29.99; 
  			this.newPlans.better.ach.dollar = 29 ;
  			this.newPlans.better.ach.cents = 99 ;
  			this.newPlans.better.ach.enrollment  = 99;
  			this.newPlans.better.services  = ['Fitness Center Access','Group Excercise Featuring Les Mills','SPINLYFE','50% JB Discount','Unlimited Tanning'];

  			this.newPlans.best.ach.price  = 39.99; 
  			this.newPlans.best.ach.dollar = 39 ;
  			this.newPlans.best.ach.cents = 99 ;
  			this.newPlans.best.ach.enrollment  = 49;
  			this.newPlans.best.services  = ['Fitness Center Access','Group Excercise Featuring Les Mills','SPINLYFE','50% JB Discount','Unlimited Tanning','Child Care','Bf.i.t.t:60 Once Weekly'];

  		//****************************************//
  			this.newPlans.basic.recommended = true;
  			this.newPlans.better.recommended = false;
  			this.newPlans.best.recommended = false;
  		}

  	}else{

  		//recommend 19.99 	

  			this.newPlans.better.ach.price  = 29.99; 
  			this.newPlans.better.ach.dollar = 29 ;
  			this.newPlans.better.ach.cents = 99 ;
  			this.newPlans.better.ach.enrollment  = 99;
  			this.newPlans.better.services  = ['Fitness Center Access','Group Excercise Featuring Les Mills','SPINLYFE','50% JB Discount','Unlimited Tanning'];

  			this.newPlans.best.ach.price  = 39.99; 
  			this.newPlans.best.ach.dollar = 39 ;
  			this.newPlans.best.ach.cents = 99 ;
  			this.newPlans.best.ach.enrollment  = 49;
  			this.newPlans.best.services  = ['Fitness Center Access','Group Excercise Featuring Les Mills','SPINLYFE','50% JB Discount','Unlimited Tanning','Child Care','Bf.i.t.t:60 Once Weekly'];

  		//****************************************//
  			this.newPlans.basic.recommended = true;
  			this.newPlans.better.recommended = false;
  			this.newPlans.best.recommended = false;

  	}
  }

  doHaveService(plan,service){
  	if(this.newPlans[plan].services.find(x => { return (x == service) ? true : false;}))
  		return true;
  	else 
  		return false;
  }
}
